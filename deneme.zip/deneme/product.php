<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ürün Listesi</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body>

<?php include "lib/navbar.php"; ?>

<!---------------------------- MAIN CONTENT ------------------------------------------>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-3">
            <div class="thumbnail">
                <img src="assets/images/bebek-mamasi.jpg" alt="bebek maması">
                <div class="caption">
                    <h3>Bebek Maması</h3>
                    <p>0-3 yaş bebek maması</p>
                    <p class="text-right price-container"><strong>Kalan 100</strong></p>
                    <p>
                        <a href="#" class="btn btn-primary btn-block" role="button">
                            <span class="glyphicon glyphicon-shopping-cart"></span> Sepete Ekle
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>



<!---------------------------- MAIN CONTENT ------------------------------------------>

<script src="assets/js/jquery-3.6.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>