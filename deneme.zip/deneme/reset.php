<?php
session_reset();
