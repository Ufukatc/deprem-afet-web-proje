-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 02 May 2023, 08:55:48
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sitesetting`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `detail` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `amount` int NOT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `products`
--

INSERT INTO `products` (`id`, `product_name`, `detail`, `amount`, `img_url`) VALUES
(1, 'Bebek Maması', '0 - 3 yaş arası bebek maması', 3, 'bebek-mamasi.png'),
(2, 'Bebek Bezi', '3 yaş bebek bezi', 3, 'bebek-bezi.png'),
(3, 'Ağrı Kesici', 'Ağrı Kesici İlaçlar', 2, 'agri-kesici.png'),
(4, 'Battaniye', 'Polar Battaniye', 5, 'battaniye.png'),
(5, 'Bebek Kıyafeti', '3 - 5 yaş arası bebek kıyafeti', 3, 'bebek-kiyafeti.png'),
(6, 'Biberon', 'Bebekler İçin Biberon', 3, 'biberon.png'),
(7, 'Çadır', '4 Kişilik Çadır', 1, 'cadir.jpg'),
(8, 'Çorap', 'Kalın Çorap', 10, 'corap.jpg'),
(9, 'Duş Jeli', '700ml Duş Jeli', 3, 'dus-jeli.jpg'),
(10, 'Erkek Alt Kıyafet', 'Erkekler İçin Alt Kıyafet', 2, 'erkek-alt'),
(11, 'Erkek Atkı', 'Kalın Yün Atkı', 3, 'erkek-atki.jpg'),
(12, 'Erkek Ayakkabı', '40 - 44 Numara Arası Erkek Ayakkabı', 2, 'erkek-ayakkabi.jpg'),
(13, 'Erkek Bere', 'Kalın Yün Bere', 4, 'erkek-bere.jpg'),
(14, 'Erkek Bot', '40 - 46 Numara Arası Erkek Bot', 3, 'erkek-bot.jpg'),
(15, 'Erkek Eldiven', 'Kalın Kışlık Eldiven', 2, 'erkek-eldiven.jpg'),
(16, 'Erkek İç Giyim', 'Esnek Kumaş İç Giyim', 7, 'erkek-ic-giyim.jpg'),
(17, 'Erkek Mont', 'Kalın Kışlık Erkek Mont', 4, 'erkek-mont/jpg'),
(18, 'Erkek Üst Giyim', 'Erkekler İçin T-shirt ve Kazaklar', 7, 'erkek-ust.jpg'),
(19, 'Gıda', 'Gıda Yardım Kolisi', 1, 'gida.jpg'),
(20, 'Havlu', 'Kalın Havlu', 10, 'havlu.jpg'),
(21, 'Isıtıcı', 'Küçük Elektrikli Isıtıcı', 1, 'isitici.jpg'),
(22, 'Kadın Alt Giyim', 'Kadınlar İçin Alt Giyim', 5, 'kadin-alt.jpg'),
(23, 'Kadın Atkı', 'Kadınlar İçin Kalın Atkı', 6, 'kadin.atki.jpg'),
(24, 'Kadın Ayakkabı', '36 - 40 Numara Arası Kadın Ayakkabı', 2, 'kadin-ayakkabi.jpg'),
(25, 'Kadın Bere', 'Kalın Yün Bere', 6, 'kadin-bere.jpg'),
(26, 'Kadın Bot', '36 - 42 Numara Arası Kadın Kışlık Bot', 3, 'kadin-bot.jpg'),
(27, 'Kadın Eldiven', 'Kışlık Kalın Eldiven', 3, 'kadin-eldiven.jpg'),
(28, 'Kadın Hijyen Malzemeleri', 'Kadınlar İçin Hijyen Malzemeleri Kutusu', 1, 'kadin-hijyen.jpg'),
(29, 'Kadın İç Giyim', 'Kadınlar İçin İç Giyim Seti', 5, 'kadin-ic-giyim.jpg'),
(30, 'Kadın Mont', 'Kalın Kışlık Mont', 3, 'kadin-mont.jpg'),
(31, 'Kadın Üst Giyim', 'Kadınlar İçin T-shirt ve Kazak Çeşitleri', 7, 'kadin-ust.jpg'),
(32, 'Oyuncak', 'Çocuklar İçin Oyuncaklar', 4, 'oyuncak.jpg'),
(33, 'Sabun', 'Sıvı ve Katı Sabun', 2, 'sabun.jpg'),
(34, 'Şampuan', '700ml Şampuan', 2, 'sampuan.jpg'),
(35, 'Yastık', 'Yumuşak Yastık', 4, 'yastik.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `_websitesettings`
--

DROP TABLE IF EXISTS `_websitesettings`;
CREATE TABLE IF NOT EXISTS `_websitesettings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `SiteName` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteTitle` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteDescription` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteKeywords` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteCopyrightText` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteLogo` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteEmailAdress` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `SiteEmailPassword` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `_websitesettings`
--

INSERT INTO `_websitesettings` (`id`, `SiteName`, `SiteTitle`, `SiteDescription`, `SiteKeywords`, `SiteCopyrightText`, `SiteLogo`, `SiteEmailAdress`, `SiteEmailPassword`) VALUES
(1, 'Ahbap Yardımlaşalım', 'Ahbap Yardımlaşalım', 'Afet Yardım Kurumu', 'sel, deprem, felaket, doğal afet, yardım', 'Copyright © 2023 Ahbap Tüm Hakları Saklıdır', 'assets/images/logo.png', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
