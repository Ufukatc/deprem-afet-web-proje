<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ürün Listesi</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body>
<?php include "lib/navbar.php"; ?>

<div class="map">
    <iframe height="780px" width="100%" src="https://afetharita.com/tr#dvf=%7B%22state%22%3A%7B%22isOpen%22%3Afalse,%22timestamp%22%3A1800000%7D,%22version%22%3A0%7D&hrf=%7B%22state%22%3A%7B%22isOpen%22%3Afalse,%22selectedCategories%22%3A%5B%22barinma%22,%22elektronik%22,%22yiyecek%22,%22saglik%22,%22lojistik%22,%22giyecek%22,%22genel%22,%22guvenlik%22%5D,%22timestamp%22%3A1800000%7D,%22version%22%3A0%7D&mg=%7B%22state%22%3A%7B%22coordinates%22%3A%7B%22lat%22%3A37.560005496474545%2C%22lng%22%3A36.90032958984376%7D%2C%22zoom%22%3A9%7D%2C%22version%22%3A0%7D&mtml=%7B%22state%22%3A%7B%22isOpen%22%3Afalse,%22mapType%22%3A%22m%22,%22mapLayers%22%3A%5B%22markers%22,%22heatmap%22%5D%7D,%22version%22%3A0%7D&sf=%7B%22state%22%3A%7B%22isOpen%22%3Afalse,%22selectedCategories%22%3A%5B%22barinma%22,%22elektronik%22,%22yiyecek%22,%22saglik%22,%22lojistik%22,%22giyecek%22,%22genel%22,%22guvenlik%22%5D%7D,%22version%22%3A0%7D"></iframe>
</div>

<script src="assets/js/jquery-3.6.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>