<?php
include "db.php";

$SettingQuary = $db->prepare("SELECT * FROM _websitesettings LIMIT 1");
$SettingQuary->execute();
$NumberOfSettings = $SettingQuary->rowCount();
$Settings = $SettingQuary->fetch(PDO::FETCH_ASSOC);

if ($NumberOfSettings > 0) {
    $SiteName = $Settings["SiteName"];
    $SiteTitle = $Settings["SiteTitle"];
    $SiteDescription = $Settings["SiteDescription"];
    $SiteKeywords = $Settings["SiteKeywords"];
    $SiteCopyrightText = $Settings["SiteCopyrightText"];
    $SiteLogo = $Settings["SiteLogo"];
    $SiteEmailAdress = $Settings["SiteEmailAdress"];
    $SiteEmailPassword = $Settings["SiteEmailPassword"];
} else {
    die();
}

