<div id="footer" class="footer">
    <?php echo $SiteCopyrightText; ?>
</div>