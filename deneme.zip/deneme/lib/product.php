<?php require_once "db.php"; ?>

<?php $products = $db->query("SELECT * from products", PDO::FETCH_OBJ)->fetchAll(); ?>

<div class="container">
    <div class="row">
        <?php foreach($products as $product){ ?>
            <div class="col-sm-6 col-md-3">
                <div class="thumbnail boxSize">
                    <img src="assets/images/<?php echo $product->img_url; ?>" alt="<?php echo $product->product_name; ?>">
                    <div class="caption">
                        <h3><?php echo $product->product_name; ?></h3>
                        <p><?php echo $product->detail; ?></p>
                        <p class="text-right price-container">Maksimum Miktar<strong> <?php echo $product->amount; ?></strong></p>
                        <p>
                            <button product-id="<?php echo $product->id; ?>" class="btn btn-primary btn-block addToCartBtn" role="button">
                                <span class="glyphicon glyphicon-shopping-cart"></span> Sepete Ekle
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>