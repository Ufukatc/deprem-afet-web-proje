<?php
$Page[0] = "lib/map.php";
$Page[1] = "lib/about-us.php";
$Page[2] = "lib/communication.php";
$Page[3] = "lib/product-help.php";
$Page[4] = "lib/product.php";
$Page[5] = "lib/shopping-cart.php";
$Page[6] = "lib/user-settings.php";
$Page[7] = "";
$Page[8] = "";
$Page[9] = "";
$Page[10] = "";
$Page[11] = "";
?>
