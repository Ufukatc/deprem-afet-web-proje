<div class="container">
    <?php if($total_count > 0){ ?>

        <h2 class="text-center">Sepetinizde <strong class="color-danger"><?php echo $total_count; ?></strong> adet ürün bulunmaktadır</h2>

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <table class="table table-hover table-bordered table-striped">
                    <thead>
                    <th class="text-center">Ürün Resmi</th>
                    <th class="text-center">Ürün Adı</th>
                    <th class="text-center">Ürün Adedi</th>
                    <th class="text-center">Sepetten Çıkar</th>
                    </thead>
                    <tbody>
                    <?php foreach ($shopping_products as $product){ ?>

                        <tr>
                            <td class="text-center" width="120">
                                <img src="assets/images/<?php echo $product->img_url; ?>" alt="<?php echo $product->product_name; ?>" width="50">
                            </td>
                            <td class="text-center"><?php echo $product->product_name; ?></td>
                            <td class="text-center">
                                <a href="cart_db.php?p=incCount&product_id=<?php echo $product->id; ?>" class="btn btn-xs btn-success">
                                    <span class="glyphicon glyphicon-plus"></span>
                                </a>
                                <input type="text" class="item-count-input" value="<?php echo $product->count; ?>">
                                <a href="cart_db.php?p=decCount&product_id=<?php echo $product->id; ?>" class="btn btn-xs btn-danger">
                                    <span class="glyphicon glyphicon-minus"></span>
                                </a>
                            <td class="text-center" width="120">
                                <button product-id="<?php echo $product->id; ?>" class="btn btn-danger btn-sm removeFromCartBtn">
                                    <span class="glyphicon glyphicon-remove"></span>
                                    Sepetten Çıkar
                                </button>
                            </td>
                            </td>
                        </tr>

                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <th colspan="4" class="text-right">
                        Toplam Ürün : <span class="color-danger"><?php echo $total_count; ?></span>
                    </th>
                    </tfoot>
                </table>
            </div>
        </div>
    <?php } else{ ?>

    <div class="alert alert-info text-center">
        <strong>Sepetinizde Henüz Bir Ürün Bulunmamaktadır. Ürünlere Gitmek İçin <a href="index.php?SP=4" class="color-danger">Tıklayınız!</a></strong>
    </div>
<?php } ?>
</div>
