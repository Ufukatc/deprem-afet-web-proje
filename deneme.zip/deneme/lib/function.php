<?php
$IPAdress			        =		$_SERVER["REMOTE_ADDR"];
$TimeStamp	    	        =		time();
$HistoryHour		        =		date("d.m.Y H:i:s", $TimeStamp);

function deleteLetters($Value){
    $Process			    =		preg_replace("/[^0-9]/","",$Value);
    $Conclusion			    =		$Process;
    return $Conclusion;
}

function revertConversions($Value){
    $ReturnIt			    =		htmlspecialchars_decode($Value, ENT_QUOTES);
    $Conclusion			    =		$ReturnIt;
    return $Conclusion;
}

function Security($Value){
    $DeleteSpaces		    =		trim($Value);
    $DeleteTags		        =		strip_tags($DeleteSpaces);
    $MakeIneffective	    =		htmlspecialchars($DeleteTags);
    $Conclusion				=		$MakeIneffective;
    return $Conclusion;
}

function FilterNumberedContents($Value){
    $DeleteSpaces			=		trim($Value);
    $DeleteTags	        	=		strip_tags($DeleteSpaces);
    $MakeIneffective		=		htmlspecialchars($DeleteTags);
    $Clean		        	=		deleteLetters($MakeIneffective);
    $Conclusion				=		$Clean;
    return $Conclusion;
}

?>