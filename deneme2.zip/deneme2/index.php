<?php
require_once("lib/settings.php");
require_once("lib/function.php");
require_once("lib/sitepages.php");

if(isset($_REQUEST["SP"])){
$SitePageIndex    = FilterNumberedContents($_REQUEST["SP"]);
}else{
$SitePageIndex    = 0;
}
?>

<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="index, follow">
    <meta name="googlebot" content="index, follow">
    <meta name="revisit-after" content="7 Days">
    <title>
        <?php echo $SiteTitle; ?>

    </title>
    <meta name="description" content="<?php echo $SiteDescription; ?>">
    <meta name="keywords" content="<?php echo $SiteKeywords; ?>">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body>
<?php include "lib/navbar.php"; ?>

<?php
if((!$SitePageIndex) or ($SitePageIndex == "") or ($SitePageIndex == 0)){
    include($Page[0]);
}else{
    require_once($Page[$SitePageIndex]);
}
?>

<?php include("lib/footer.php"); ?>

<script src="assets/js/jquery-3.6.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
<?php
$db		=		null;
?>