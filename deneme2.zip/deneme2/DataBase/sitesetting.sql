-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 10 May 2023, 11:22:43
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sitesetting`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `detail` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount` int NOT NULL,
  `img_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `products`
--

INSERT INTO `products` (`id`, `product_name`, `detail`, `amount`, `img_url`) VALUES
(1, 'Bebek Maması', '0 - 3 yaş arası bebek maması\r\n ', 3, 'bebek-mamasi.jpg'),
(2, 'Bebek Bezi', '3 yaş bebek bezi\r\n ', 3, 'bebek-bezi.jpg'),
(3, 'Ağrı Kesici', 'Ağrı Kesici İlaçlar\r\n ', 2, 'agri-kesici.jpg'),
(4, 'Battaniye', 'Polar Battaniye\r\n ', 5, 'battaniye.jpg'),
(5, 'Bebek Kıyafeti', '3 - 5 yaş arası bebek kıyafeti\r\n ', 3, 'bebek-kiyafeti.jpg'),
(6, 'Biberon', 'Bebekler İçin Biberon\r\n ', 3, 'biberon.jpg'),
(7, 'Çadır', '4 Kişilik Çadır', 1, 'cadir.jpg'),
(8, 'Çorap', 'Kalın Çorap', 10, 'corap.jpg'),
(9, 'Duş Jeli', '700ml Duş Jeli', 3, 'dus-jeli.jpg'),
(10, 'Erkek Alt Kıyafet', 'Erkekler İçin Alt Kıyafet', 2, 'erkek-alt'),
(11, 'Erkek Atkı', 'Kalın Yün Atkı', 3, 'erkek-atki.jpg'),
(12, 'Erkek Ayakkabı', '40 - 44 Numara Arası Ayakkabı', 2, 'erkek-ayakkabi.jpg'),
(13, 'Erkek Bere', 'Kalın Yün Bere', 4, 'erkek-bere.jpg'),
(14, 'Erkek Bot', '40 - 46 Numara Arası Erkek Bot', 3, 'erkek-bot.jpg'),
(15, 'Erkek Eldiven', 'Kalın Kışlık Eldiven', 2, 'erkek-eldiven.jpg'),
(16, 'Erkek İç Giyim', 'Esnek Kumaş İç Giyim', 7, 'erkek-ic-giyim.jpg'),
(17, 'Erkek Mont', 'Kalın Kışlık Erkek Mont', 4, 'erkek-mont.jpg'),
(18, 'Erkek Üst Giyim', 'Erkekler İçin T-shirt ve Kazaklar', 7, 'erkek-ust.jpg'),
(19, 'Gıda', 'Gıda Yardım Kolisi', 1, 'gida.jpg'),
(20, 'Havlu', 'Kalın Havlu', 10, 'havlu.jpg'),
(21, 'Isıtıcı', 'Küçük Elektrikli Isıtıcı', 1, 'isitici.jpg'),
(22, 'Kadın Alt Giyim', 'Kadınlar İçin Alt Giyim', 5, 'kadin-alt.jpg'),
(23, 'Kadın Atkı', 'Kadınlar İçin Kalın Atkı', 6, 'kadin-atki.jpg'),
(24, 'Kadın Ayakkabı', '36 - 40 Numara Arası Ayakkabı', 2, 'kadin-ayakkabi.jpg'),
(25, 'Kadın Bere', 'Kalın Yün Bere', 6, 'kadin-bere.jpg'),
(26, 'Kadın Bot', '36-42 Numara Arası Kışlık Bot', 3, 'kadin-bot.jpg'),
(27, 'Kadın Eldiven', 'Kışlık Kalın Eldiven', 3, 'kadin-eldiven.jpg'),
(28, 'Kadın Hijyen Kolisi', 'Hijyen Malzemeleri Kolisi', 1, 'kadin-hijyen.jpg'),
(29, 'Kadın İç Giyim', 'Kadınlar İçin İç Giyim Seti', 5, 'kadin-ic-giyim.jpg'),
(30, 'Kadın Mont', 'Kalın Kışlık Mont', 3, 'kadin-mont.jpg'),
(31, 'Kadın Üst Giyim', 'T-shirt ve Kazak Çeşitleri', 7, 'kadin-ust.jpg'),
(32, 'Oyuncak', 'Çocuklar İçin Oyuncaklar', 4, 'oyuncak.jpg'),
(33, 'Sabun', 'Sıvı ve Katı Sabun', 2, 'sabun.jpg'),
(34, 'Şampuan', '700ml Şampuan', 2, 'sampuan.jpg'),
(35, 'Yastık', 'Yumuşak Yastık', 4, 'yastik.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_history` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_name_surname` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_mail` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_gsm` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `user_active` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1',
  `admin` enum('0','1') COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `_websitesettings`
--

DROP TABLE IF EXISTS `_websitesettings`;
CREATE TABLE IF NOT EXISTS `_websitesettings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `SiteName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteTitle` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteDescription` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteKeywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteCopyrightText` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteLogo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteEmailAdress` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SiteEmailPassword` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `_websitesettings`
--

INSERT INTO `_websitesettings` (`id`, `SiteName`, `SiteTitle`, `SiteDescription`, `SiteKeywords`, `SiteCopyrightText`, `SiteLogo`, `SiteEmailAdress`, `SiteEmailPassword`) VALUES
(1, 'Ahbap Yardımlaşalım', 'Ahbap Yardımlaşalım', 'Afet Yardım Kurumu', 'sel, deprem, felaket, doğal afet, yardım', 'Copyright © 2023 Ahbap Tüm Hakları Saklıdır', 'assets/images/logo.png', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
