<div class="login-conservative"></div>
<div class="login">
    <div class="login-screen">
        <div class="app-title">
            <h1>Giriş Yap</h1>
        </div>
        <form action="index.php?SP=9" method="post">
            <div class="login-form">
                <div class="control-group">
                    <input type="text" name="usermail" class="login-field" placeholder="Mail Adresiniz" id="login-mail">
                    <label class="login-field-icon fui-user" for="login-mail"></label>
                </div>
                <div class="control-group">
                    <input type="password" name="password" class="login-field" placeholder="Şifreniz" id="login-pass">
                    <label class="login-field-icon fui-user" for="login-pass"></label>
                </div>
                <button href="index.php?SP=7" name="login" class="btn btn-primary btn-large btn-block">Giriş Yap</button>
            </div>
        </form>
        <a href="index.php?SP=8"><button class="btn btn-primary btn-large btn-block">Kayıt Ol</button></a>
    </div>
</div>
<div class="login-conservative"></div>