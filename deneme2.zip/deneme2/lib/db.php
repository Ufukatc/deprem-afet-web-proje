<?php
try{
    $db = new PDO("mysql:hostname=localhost;dbname=sitesetting;charset=utf8","root","root");
}catch(PDOException $e){
    die();
}