<?php
require 'lib/db.php';
ob_start();


if(isset($_POST['sign-in'])){
    $usermail = $_POST['usermail'];
    $password = $_POST['password'];
    $password_again = @$_POST['password_again'];
    $username = $_POST['username'];
    $usergsm = $_POST['usergsm'];

    if(!$username){
        echo "Lütfen Mail Adresinizi Giriniz!";
        header('Refresh:2; index.php?SP=8');
    }
    else if(!$password || !$password_again){
        echo "Lütfen Şifrenizi Giriniz!";
        header('Refresh:2; index.php?SP=8');
    }
    else if($password != $password_again){
        echo "Girdiğiniz Şifreler Birbirleri ile Aynı Olmalıdır!";
        header('Refresh:2; index.php?SP=8');
    }
    else{
        $SQL = $db->prepare('INSERT INTO users SET user_mail = ?, user_name_surname = ?, user_gsm = ?, password = ?');
        $add = $SQL->execute([
            $usermail,
            $username,
            $usergsm,
            $password
        ]);
        
        if($add){
            echo "Kaydınız Başarıyla Eklendi, Yönlendiriliyorsunuz!";
            header('Refresh:2; index.php?SP=7');
        }
        else{
            echo "bir hata oluştu tekrar kontrol ediniz!";
            header('Refresh:2; index.php?SP=8');
        }
    }
}
if(isset($_POST['login'])){
    $usermail = $_POST['usermail'];
    $password = $_POST['password'];

    if(!$usermail){
        echo "Lütfen Mail Adresinizi Giriniz!";
        header('Refresh:2; index.php?SP=7');
    }
    else if(!$password){
        echo "Lütfen Şifrenizi Giriniz!";
        header('Refresh:2; index.php?SP=7');
    }
    else{
        $user_query = $db->prepare('SELECT * FROM users WHERE user_mail = ? AND password = ?');
        $user_query->execute([
            $usermail,
            $password
        ]);

        $say = $user_query->rowCount();
        if($say==1){
            $_SESSION['usermail']=$usermail;
            $_SESSION['password']=$password;
            $_SESSION['loggedin'] =true;
            echo "Giriş Yaptınız, Ana Sayfaya Yönlendiriliyorsunuz.";
            header('Refresh:2; index.php?SP=0');
        }
        else{
            echo "Bir Hata Oluştu, Bilgilerinizi Tekrar Kontrol Ediniz!";
            header('Refresh:2; index.php?SP=7');
        }
    }
}


?>