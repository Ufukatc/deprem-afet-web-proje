<?php
require 'lib/db.php';
?>

<div class="record-conservative"></div>
<div class="login">
    <div class="login-screen">
        <div class="app-title">
            <h1>Kayıt Ol</h1>
        </div>
        <form action="index.php?SP=9" method="post">
            <div class="login-form">
                <div class="control-group">
                    <input type="text" name="usermail" class="login-field" placeholder="Mail Adresiniz" id="login-mail">
                    <label class="login-field-icon fui-user" for="login-mail"></label>
                </div>
                <div class="control-group">
                    <input type="text" name="username" class="login-field" placeholder="Adınız - Soy Adınız" id="login-name">
                    <label class="login-field-icon fui-user" for="login-name"></label>
                </div>
                <div class="control-group">
                    <input type="text" name="usergsm" class="login-field" placeholder="Telefon Numaranız" id="login-gsm">
                    <label class="login-field-icon fui-user" for="login-gsm"></label>
                </div>
                <div class="control-group">
                    <input type="password" name="password" class="login-field" placeholder="Şifreniz" id="login-pass">
                    <label class="login-field-icon fui-user" for="login-pass"></label>
                </div>
                <div class="control-group">
                    <input type="password" name="password_again" class="login-field" placeholder="Şifrenizi Onaylayın" id="login-pass">
                    <label class="login-field-icon fui-user" for="login-pass"></label>
                </div>
                <button href="index.php?SP=8" name="sign-in" class="btn btn-primary btn-large btn-block">Kayıt Ol</button>
            </div>
        </form>
        <a href="index.php?SP=7"><button class="btn btn-primary btn-large btn-block">Giriş Yap</button></a>
    </div>
</div>
<div class="record-conservative"></div>