<?php require_once "lib/db.php"; ?>
<?php include("lib/user-controller.php"); ?>

<?php $products = $db->query("SELECT * from products", PDO::FETCH_OBJ)->fetchAll(); ?>

<div class="container">
    <div class="row">
        <?php foreach($products as $product){ ?>
            <div class="col-sm-6 col-md-3">
                <div class="thumbnail boxSize">
                       <img src="assets/images/<?php echo $product->img_url; ?>" alt="<?php echo $product->product_name; ?>">
                    <div class="caption">
                        <h3><?php echo $product->product_name; ?></h3>
                        <div class="img-conservative"></div>
                        <p>
                            <button product-id="<?php echo $product->id; ?>" class="btn btn-primary btn-block addToCartBtn" role="button">
                                <span class="glyphicon glyphicon-shopping-cart"></span> Sepete Ekle
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    
</div>