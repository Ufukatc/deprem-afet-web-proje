<?php
session_start();
if(isset($_SESSION["shoppingCart"])){
    $shoppingCart = $_SESSION["shoppingCart"];

    $total_count = $shoppingCart["summary"]["total_count"];
    $shopping_products = $shoppingCart["products"];
}else{
    $total_count = 0;
}
?>


<nav class="navbar navbar-default navbar-color">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php?SP=0"><img src="<?php echo $SiteLogo; ?>" alt="Ahbap Logo" height="26"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-nav"bar-collapse-1">
        <ul class="nav navbar-nav">
            <li><a href="index.php?SP=0">Anasayfa</a></li>
            <li><a href="index.php?SP=1">Hakkımızda</a></li>
            <li><a href="index.php?SP=2">İletişim</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Yardım Paneli <span class="caret white-color"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="index.php?SP=3">Yardım Et</a></li>
                    <li><a href="index.php?SP=4">Yardım Al</a></li>
                </ul>
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="index.php?SP=5">
                    <span class="glyphicon glyphicon-shopping-cart cart-icon white-color"></span>
                    <span class="badge cart-count"><?php echo $total_count; ?></span>
                </a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user white-color"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="index.php?SP=6">Ayarlar</a></li>
                </ul>
            </li>
        </ul>
    </div>
    </div>
</nav>