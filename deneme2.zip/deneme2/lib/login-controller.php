<?php
$_SESSION['loggedin'] =false;
echo "Çıkış Yaptınız, Ana Sayfaya Yönlendiriliyorsunuz.";
header('Refresh:2; index.php?SP=0');